import { useState } from "react";

// ── Palette ───────────────────────────────────────────────
const C = {
  lime:      "#AAFF45",
  teal:      "#00C4B4",
  tealDark:  "#008C80",
  tealLight: "#E0FAF8",
  limeLight: "#F2FFDF",
  bg:        "#F7FAFA",
  bgCard:    "#FFFFFF",
  ink:       "#0F0F0F",
  inkMid:    "#555555",
  inkLight:  "#AAAAAA",
  success:   "#00C853",
  danger:    "#E53935",
  border:    "#E4EEEC",
  community: "#7B4FFF",  // distinct purple only for community feature
  communityLight: "#F0EBFF",
};

const REASONS = ["Family or friend support","Sending funds to self","Property payment","Purchase of services","Education fees","Medical expenses","Business payment","Other"];
const SAVED_RECEIVERS_INIT = [
  {id:1,first:"Emmanuel",last:"Keteku",          phone:"541435977",reason:"Family or friend support"},
  {id:2,first:"Kwesi",   last:"Kuntununku Asante",phone:"244189023",reason:"Family or friend support"},
  {id:3,first:"One",     last:"Philipo Ventures", phone:"201234567",reason:"Business payment"},
  {id:4,first:"Yvonne",  last:"Nana Afua Idun",   phone:"554321098",reason:"Family or friend support"},
];

// Simulated community pool total (GHS)
const POOL_TOTAL = 4820;
const POOL_TARGET = 10000;

// ── Flags ─────────────────────────────────────────────────
const GhanaFlag = () => (
  <svg width="22" height="15" viewBox="0 0 22 15" style={{borderRadius:3,flexShrink:0}}>
    <rect width="22" height="15" fill="#006B3F"/>
    <rect width="22" height="10" fill="#FCD116"/>
    <rect width="22" height="5" fill="#CE1126"/>
    <polygon points="11,3.5 12,6.5 15,6.5 12.5,8.3 13.5,11.3 11,9.5 8.5,11.3 9.5,8.3 7,6.5 10,6.5" fill="#000"/>
  </svg>
);
const UKFlag = () => (
  <svg width="22" height="15" viewBox="0 0 22 15" style={{borderRadius:3,flexShrink:0}}>
    <rect width="22" height="15" fill="#012169"/>
    <path d="M0,0 L22,15 M22,0 L0,15" stroke="#fff" strokeWidth="3"/>
    <path d="M0,0 L22,15 M22,0 L0,15" stroke="#C8102E" strokeWidth="1.5"/>
    <path d="M11,0 V15 M0,7.5 H22" stroke="#fff" strokeWidth="4.5"/>
    <path d="M11,0 V15 M0,7.5 H22" stroke="#C8102E" strokeWidth="2.5"/>
  </svg>
);

// ── Shared UI ─────────────────────────────────────────────
const Tick = () => (
  <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
    <circle cx="6.5" cy="6.5" r="6.5" fill={C.success} opacity="0.15"/>
    <path d="M3.5 6.5l2 2 4-4" stroke={C.success} strokeWidth="1.8" strokeLinecap="round"/>
  </svg>
);
const Arrow = ({dir="right",color=C.inkLight}) => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round">
    {dir==="right"&&<path d="M6 3l5 5-5 5"/>}
    {dir==="left" &&<path d="M10 3L5 8l5 5"/>}
  </svg>
);
const Pill = ({children,bg,color}) => (
  <span style={{background:bg,color,fontSize:10,fontWeight:700,padding:"3px 8px",borderRadius:20,letterSpacing:"0.4px"}}>{children}</span>
);
const TealBtn = ({children,onClick,style={}}) => (
  <button onClick={onClick} style={{width:"100%",background:C.teal,color:"#fff",border:"none",borderRadius:16,padding:16,fontSize:16,fontWeight:800,cursor:"pointer",fontFamily:"'Plus Jakarta Sans',sans-serif",letterSpacing:"-0.2px",...style}}>{children}</button>
);
const LimeBtn = ({children,onClick,style={}}) => (
  <button onClick={onClick} style={{width:"100%",background:C.lime,color:C.ink,border:"none",borderRadius:16,padding:16,fontSize:16,fontWeight:800,cursor:"pointer",fontFamily:"'Plus Jakarta Sans',sans-serif",letterSpacing:"-0.2px",...style}}>{children}</button>
);
const GhostBtn = ({children,onClick}) => (
  <button onClick={onClick} style={{width:"100%",background:"transparent",color:C.inkMid,border:`1.5px solid ${C.border}`,borderRadius:16,padding:15,fontSize:15,fontWeight:600,cursor:"pointer",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{children}</button>
);

// Toggle switch component
const Toggle = ({on,onToggle,color=C.teal}) => (
  <div onClick={onToggle} style={{width:48,height:28,borderRadius:14,background:on?color:C.border,cursor:"pointer",position:"relative",transition:"background 0.2s",flexShrink:0}}>
    <div style={{position:"absolute",top:3,left:on?23:3,width:22,height:22,borderRadius:"50%",background:"#fff",boxShadow:"0 1px 4px rgba(0,0,0,0.2)",transition:"left 0.2s"}}/>
  </div>
);

// Bottom sheet
const Sheet = ({children,onClose,title}) => (
  <div style={{position:"absolute",inset:0,zIndex:50,display:"flex",flexDirection:"column",justifyContent:"flex-end"}}>
    <div style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.45)"}} onClick={onClose}/>
    <div style={{position:"relative",background:"#fff",borderRadius:"24px 24px 0 0",padding:"20px 24px 40px",zIndex:1,maxHeight:"75%",overflowY:"auto"}}>
      <div style={{width:36,height:4,borderRadius:2,background:C.border,margin:"0 auto 16px"}}/>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <h3 style={{fontSize:20,fontWeight:800,color:C.ink,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{title}</h3>
        <button onClick={onClose} style={{background:C.border,border:"none",borderRadius:"50%",width:30,height:30,cursor:"pointer",fontSize:14,color:C.inkMid,display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
      </div>
      {children}
    </div>
  </div>
);

// Progress bar
const ProgressBar = ({value,max,color}) => (
  <div style={{height:8,borderRadius:4,background:C.border,overflow:"hidden"}}>
    <div style={{height:"100%",width:`${Math.min(100,(value/max)*100)}%`,background:color,borderRadius:4,transition:"width 0.5s"}}/>
  </div>
);

// Logos
const LogoMark = ({size=32,dark=false}) => (
  <div style={{width:size,height:size,borderRadius:size*0.3,background:dark?C.teal:"rgba(255,255,255,0.18)",backdropFilter:dark?"none":"blur(10px)",border:dark?"none":"1px solid rgba(255,255,255,0.3)",display:"flex",alignItems:"center",justifyContent:"center"}}>
    <svg width={size*0.55} height={size*0.55} viewBox="0 0 16 16" fill="none">
      <path d="M8 1.5 L14.5 8 L8 14.5 L1.5 8 Z" fill={C.lime}/>
      <circle cx="8" cy="8" r="2.8" fill="#fff"/>
    </svg>
  </div>
);
const LogoFull = ({white=false}) => (
  <div style={{display:"flex",alignItems:"center",gap:8}}>
    <LogoMark size={30} dark={!white}/>
    <span style={{fontSize:22,fontWeight:800,color:white?"#fff":C.ink,letterSpacing:"-0.5px",fontFamily:"'Plus Jakarta Sans',sans-serif",textShadow:white?"0 1px 6px rgba(0,0,0,0.25)":"none"}}>sika</span>
  </div>
);

// Art
const ART = [
  {bg:"linear-gradient(165deg,#0D0500 0%,#6B1A00 25%,#C24B00 52%,#E8890A 75%,#F5C842 100%)",overlay:`radial-gradient(ellipse at 35% 55%,rgba(240,120,0,0.45) 0%,transparent 52%),radial-gradient(ellipse at 70% 25%,rgba(120,20,0,0.55) 0%,transparent 45%)`,artist:"Kwame Akoto-Bamfo",title:"Ancestral Voices"},
  {bg:"linear-gradient(150deg,#050E03 0%,#0F3312 28%,#1E6624 55%,#5CB82A 80%,#AAFF45 100%)",overlay:`radial-gradient(ellipse at 60% 40%,rgba(90,200,40,0.25) 0%,transparent 52%),radial-gradient(ellipse at 25% 70%,rgba(5,30,8,0.65) 0%,transparent 45%)`,artist:"Amoako Boafo",title:"Sunday Best"},
  {bg:"linear-gradient(155deg,#040D14 0%,#072C48 28%,#0A5870 55%,#00A89A 80%,#AAFF45 100%)",overlay:`radial-gradient(ellipse at 42% 38%,rgba(0,180,165,0.3) 0%,transparent 50%),radial-gradient(ellipse at 72% 62%,rgba(4,13,20,0.65) 0%,transparent 45%)`,artist:"Lynette Yiadom-Boakye",title:"A Concentration"},
];
const ArtSilhouette = ({i}) => {
  if(i===0) return(<svg viewBox="0 0 335 380" fill="none" style={{position:"absolute",inset:0,width:"100%",height:"100%"}}>{[0,1,2,3,4].map(n=><rect key={n} x={n*70-10} y="0" width="28" height="380" fill="#FFA500" opacity="0.06" transform={`rotate(${n%2===0?-3:3} ${n*70+14} 190)`}/>)}<ellipse cx="168" cy="355" rx="55" ry="10" fill="rgba(0,0,0,0.25)"/><rect x="150" y="230" width="36" height="120" rx="18" fill="rgba(0,0,0,0.55)"/><circle cx="168" cy="208" r="30" fill="rgba(0,0,0,0.55)"/><path d="M150 265 Q108 240 85 200" stroke="rgba(0,0,0,0.55)" strokeWidth="26" strokeLinecap="round" fill="none"/><path d="M186 265 Q222 235 248 195" stroke="rgba(0,0,0,0.55)" strokeWidth="26" strokeLinecap="round" fill="none"/>{[[120,60],[168,35],[220,55],[145,80],[192,75]].map(([cx,cy],n)=><circle key={n} cx={cx} cy={cy} r={n===1?4:2.5} fill="#F5C842" opacity={n===1?0.9:0.6}/>)}</svg>);
  if(i===1) return(<svg viewBox="0 0 335 380" fill="none" style={{position:"absolute",inset:0,width:"100%",height:"100%"}}>{[50,100,150,200,250,300].map((x,n)=><ellipse key={n} cx={x} cy={30+n%2*20} rx="35" ry="22" fill="rgba(20,80,10,0.3)" transform={`rotate(${n*15} ${x} ${30+n%2*20})`}/>)}<ellipse cx="168" cy="358" rx="52" ry="9" fill="rgba(0,0,0,0.2)"/><rect x="148" y="230" width="40" height="125" rx="20" fill="rgba(5,20,5,0.6)"/><circle cx="168" cy="206" r="34" fill="rgba(5,20,5,0.6)"/><path d="M148 260 Q118 270 108 300" stroke="rgba(5,20,5,0.6)" strokeWidth="22" strokeLinecap="round" fill="none"/><path d="M188 260 Q218 270 228 300" stroke="rgba(5,20,5,0.6)" strokeWidth="22" strokeLinecap="round" fill="none"/><circle cx="168" cy="100" r="60" fill="#AAFF45" opacity="0.08"/></svg>);
  return(<svg viewBox="0 0 335 380" fill="none" style={{position:"absolute",inset:0,width:"100%",height:"100%"}}><path d="M0 240 Q55 215 110 240 Q165 265 220 240 Q275 215 335 240 L335 380 L0 380Z" fill="rgba(0,100,120,0.3)"/><path d="M0 265 Q55 244 110 265 Q165 286 220 265 Q275 244 335 265 L335 380 L0 380Z" fill="rgba(0,160,150,0.25)"/><circle cx="168" cy="115" r="48" fill="#F5A623" opacity="0.25"/><circle cx="168" cy="115" r="28" fill="#FFD700" opacity="0.3"/><rect x="152" y="265" width="32" height="102" rx="16" fill="rgba(4,13,20,0.7)"/><circle cx="168" cy="246" r="26" fill="rgba(4,13,20,0.7)"/><path d="M152 290 Q125 278 112 258" stroke="rgba(4,13,20,0.7)" strokeWidth="20" strokeLinecap="round" fill="none"/><path d="M184 290 Q210 275 224 255" stroke="rgba(4,13,20,0.7)" strokeWidth="20" strokeLinecap="round" fill="none"/></svg>);
};

// ══════════════════════════════════════════════════════════
export default function SikaApp() {
  const [screen,  setScreen]        = useState("splash");
  const [onbStep, setOnbStep]       = useState(1);
  const [sendStep,setSendStep]      = useState(1);
  const [amount,  setAmount]        = useState("100");
  const [artIdx,  setArtIdx]        = useState(0);
  const [alertRate,setAlertRate]    = useState("17.00");
  const [alertActive,setAlertActive]= useState(false);

  // Community
  const [communityOn,  setCommunityOn]  = useState(false);
  const [poolTotal,    setPoolTotal]    = useState(POOL_TOTAL);

  // Receiver
  const [receivers,   setReceivers]   = useState(SAVED_RECEIVERS_INIT);
  const [selectedRx,  setSelectedRx]  = useState(null);
  const [sheetRx,     setSheetRx]     = useState(null);
  const [editRx,      setEditRx]      = useState(null);
  const [showReasonSheet,setShowReasonSheet] = useState(false);
  const [rxFirst,setRxFirst] = useState("");
  const [rxLast, setRxLast]  = useState("");
  const [rxPhone,setRxPhone] = useState("");
  const [rxReason,setRxReason]= useState("");
  const [rxNetwork,setRxNetwork] = useState("mtn");

  // Referral
  const [codeCopied, setCodeCopied] = useState(false);

  const fxRate    = 16.42;
  const receives  = amount ? (parseFloat(amount||0)*fxRate).toFixed(2) : "0.00";
  const communityContrib = amount ? (parseFloat(amount||0)*0.001).toFixed(2) : "0.00";
  const referralCode = "SIKA-YAW";

  const goHome = () => setScreen("home");
  const goSend = () => { setScreen("send"); setSendStep(1); };

  const card = (extra={}) => ({background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:20,padding:"18px",...extra});
  const lbl  = (extra={}) => ({fontSize:10,fontWeight:700,color:C.inkLight,letterSpacing:"0.9px",textTransform:"uppercase",...extra});
  const bigN = (color=C.ink) => ({fontSize:38,fontWeight:800,color,letterSpacing:"-1.5px",fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1});

  const openAddReceiver  = () => { setEditRx(null); setRxFirst(""); setRxLast(""); setRxPhone(""); setRxReason(""); setRxNetwork("mtn"); setScreen("editReceiver"); };
  const openEditReceiver = (rx) => { setEditRx(rx); setRxFirst(rx.first); setRxLast(rx.last); setRxPhone(rx.phone); setRxReason(rx.reason); setRxNetwork(rx.network||"mtn"); setSheetRx(null); setScreen("editReceiver"); };
  const saveReceiver = () => {
    if(!rxFirst||!rxPhone) return;
    if(editRx) setReceivers(rs=>rs.map(r=>r.id===editRx.id?{...r,first:rxFirst,last:rxLast,phone:rxPhone,reason:rxReason,network:rxNetwork}:r));
    else { const n={id:Date.now(),first:rxFirst,last:rxLast,phone:rxPhone,reason:rxReason,network:rxNetwork}; setReceivers(rs=>[...rs,n]); }
    setScreen("send"); setSendStep(2);
  };
  const deleteReceiver = (id) => { setReceivers(rs=>rs.filter(r=>r.id!==id)); setSheetRx(null); };

  const copyCode = () => { setCodeCopied(true); setTimeout(()=>setCodeCopied(false),2000); };

  const NAV = [
    {id:"home",      label:"Home",     Icon:({a})=><svg width="20" height="20" viewBox="0 0 24 24" fill={a?C.teal:"none"} stroke={a?C.teal:C.inkLight} strokeWidth="2"><path d="M3 12L12 3l9 9v9a1 1 0 01-1 1H4a1 1 0 01-1-1v-9z"/></svg>},
    {id:"send",      label:"Send",     Icon:({a})=><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={a?C.teal:C.inkLight} strokeWidth="2"><path d="M22 2L11 13M22 2L15 22l-4-9-9-4 20-7z"/></svg>},
    {id:"community", label:"Community",Icon:({a})=><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={a?C.community:C.inkLight} strokeWidth="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>},
    {id:"transfers", label:"History",  Icon:({a})=><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={a?C.teal:C.inkLight} strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M7 8h10M7 12h7M7 16h5"/></svg>},
    {id:"profile",   label:"Profile",  Icon:({a})=><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={a?C.teal:C.inkLight} strokeWidth="2"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>},
  ];

  // ══════════════════════════════════════════════════════
  // ONBOARDING (condensed — same as v5)
  // ══════════════════════════════════════════════════════
  const SplashScreen = () => (
    <div style={{height:"100%",background:"linear-gradient(160deg,#040D14 0%,#007A6E 50%,#00C4B4 80%,#AAFF45 100%)",display:"flex",flexDirection:"column",justifyContent:"space-between",padding:"50px 28px 48px",position:"relative",overflow:"hidden"}}>
      {[200,300,420].map((r,i)=><div key={i} style={{position:"absolute",top:"38%",left:"50%",transform:"translate(-50%,-50%)",width:r,height:r,borderRadius:"50%",border:`1px solid rgba(255,255,255,${0.06-i*0.015})`,pointerEvents:"none"}}/>)}
      <div style={{position:"absolute",top:0,right:0,width:6,height:"100%",background:`repeating-linear-gradient(to bottom,${C.lime} 0px,${C.lime} 18px,transparent 18px,transparent 32px,${C.teal} 32px,${C.teal} 50px,transparent 50px,transparent 64px)`}}/>
      <div style={{position:"relative"}}><LogoFull white/></div>
      <div style={{position:"relative"}}>
        <p style={{color:"rgba(255,255,255,0.6)",fontSize:12,fontWeight:600,letterSpacing:"1px",textTransform:"uppercase",marginBottom:12}}>Built for the diaspora</p>
        <h1 style={{fontSize:38,fontWeight:800,color:"#fff",letterSpacing:"-1.5px",lineHeight:1.1,marginBottom:16,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Send money<br/>home. For free.</h1>
        <p style={{color:"rgba(255,255,255,0.65)",fontSize:15,lineHeight:1.6,marginBottom:36}}>Zero fees. Mid-market rates.<br/>Straight to MTN Mobile Money.</p>
        <LimeBtn onClick={()=>{setScreen("onboarding");setOnbStep(1)}}>Get started →</LimeBtn>
        <button onClick={()=>{setScreen("onboarding");setOnbStep(2)}} style={{width:"100%",background:"transparent",color:"rgba(255,255,255,0.6)",border:"none",marginTop:14,fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>Already have an account? Sign in</button>
      </div>
    </div>
  );

  const OnboardingScreen = () => {
    if(onbStep===1) return(
      <div style={{height:"100%",display:"flex",flexDirection:"column",padding:"40px 28px",background:C.bg}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:36}}><LogoFull/><button onClick={()=>setOnbStep(2)} style={{background:"transparent",border:"none",color:C.inkMid,fontSize:14,fontWeight:600,cursor:"pointer"}}>Skip</button></div>
        <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:24}}>
          <div style={{width:210,height:210,borderRadius:"50%",background:`linear-gradient(135deg,${C.tealLight},${C.limeLight})`,display:"flex",alignItems:"center",justifyContent:"center",position:"relative"}}>
            <div style={{textAlign:"center"}}><div style={{fontSize:48,marginBottom:4}}>🌍</div><div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8,marginBottom:6}}><UKFlag/><span style={{fontSize:16,color:C.inkMid}}>→</span><GhanaFlag/></div><div style={{fontSize:20,fontWeight:800,color:C.teal,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>£100 → GHS 1,642</div><div style={{fontSize:11,color:C.success,fontWeight:700,marginTop:4}}>✓ 0% fees · Instant</div></div>
          </div>
        </div>
        <h2 style={{fontSize:24,fontWeight:800,color:C.ink,letterSpacing:"-0.8px",marginBottom:8,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>The rate your family deserves</h2>
        <p style={{color:C.inkMid,fontSize:14,lineHeight:1.6,marginBottom:24}}>SIKA passes 100% of the mid-market exchange rate to your recipient. No hidden margins. No surprises.</p>
        <div style={{display:"flex",gap:6,justifyContent:"center",marginBottom:20}}>{[0,1,2].map(i=><div key={i} style={{width:i===0?20:6,height:6,borderRadius:3,background:i===0?C.teal:C.border}}/>)}</div>
        <TealBtn onClick={()=>setOnbStep(2)}>Create free account →</TealBtn>
      </div>
    );
    if(onbStep===2) return(
      <div style={{padding:"50px 24px 24px"}}>
        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:24}}><button onClick={()=>setOnbStep(1)} style={{width:34,height:34,borderRadius:11,background:C.border,border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><Arrow dir="left" color={C.ink}/></button><LogoFull/></div>
        <h2 style={{fontSize:24,fontWeight:800,color:C.ink,letterSpacing:"-0.5px",marginBottom:4,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Create your account</h2>
        <p style={{color:C.inkMid,fontSize:14,marginBottom:24}}>Takes 2 minutes. FCA regulated.</p>
        {[{label:"First name",ph:"Yaw"},{label:"Last name",ph:"Mfodwo"},{label:"Email",ph:"yaw@email.com"},{label:"Phone",ph:"+44 7700 000000"}].map(f=>(
          <div key={f.label} style={card({marginBottom:10})}><p style={lbl({marginBottom:6})}>{f.label}</p><input placeholder={f.ph} style={{fontSize:16,fontWeight:600,color:C.ink,background:"transparent",border:"none",outline:"none",width:"100%",fontFamily:"'DM Sans',sans-serif"}}/></div>
        ))}
        <div style={card({marginBottom:20,background:C.limeLight,border:"1px solid #c8f07a"})}><p style={{fontSize:12,color:"#3d7a00",fontWeight:500,lineHeight:1.5}}>🔒 Encrypted and FCA-authorised. We never sell your data.</p></div>
        <TealBtn onClick={()=>setOnbStep(3)} style={{marginBottom:10}}>Continue →</TealBtn>
      </div>
    );
    if(onbStep===3) return(
      <div style={{padding:"50px 24px 32px",display:"flex",flexDirection:"column",height:"100%"}}>
        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:32}}><button onClick={()=>setOnbStep(2)} style={{width:34,height:34,borderRadius:11,background:C.border,border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><Arrow dir="left" color={C.ink}/></button><p style={lbl()}>Step 2 of 2 — Identity</p></div>
        <div style={{textAlign:"center",marginBottom:28}}><div style={{width:80,height:80,borderRadius:22,background:C.tealLight,display:"flex",alignItems:"center",justifyContent:"center",fontSize:40,margin:"0 auto 16px"}}>🪪</div><h2 style={{fontSize:22,fontWeight:800,color:C.ink,letterSpacing:"-0.5px",marginBottom:8,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Verify your identity</h2><p style={{color:C.inkMid,fontSize:14,lineHeight:1.6}}>FCA regulations require us to confirm who you are. Takes 2–3 minutes.</p></div>
        <div style={card({marginBottom:24})}><p style={lbl({marginBottom:12})}>What you'll need</p>{[{e:"🪪",t:"Valid passport or driving licence"},{e:"🤳",t:"A short selfie or live photo"},{e:"☀️",t:"Good lighting and clear background"}].map(i=><div key={i.t} style={{display:"flex",alignItems:"center",gap:12,marginBottom:12}}><div style={{width:34,height:34,borderRadius:10,background:C.tealLight,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>{i.e}</div><p style={{color:C.ink,fontSize:13,lineHeight:1.4}}>{i.t}</p></div>)}</div>
        <div style={{marginTop:"auto"}}><TealBtn onClick={()=>setOnbStep(4)} style={{marginBottom:10}}>Start identity check →</TealBtn><GhostBtn onClick={()=>setOnbStep(4)}>I'll do this later</GhostBtn></div>
      </div>
    );
    if(onbStep===4) return(
      <div style={{padding:"50px 24px 32px",display:"flex",flexDirection:"column",alignItems:"center",height:"100%"}}>
        <div style={{width:"100%",marginBottom:32}}><p style={lbl({color:C.teal})}>Powered by Sumsub · Secure KYC</p></div>
        <div style={{width:"100%",flex:1,background:"#fff",borderRadius:24,border:`2px dashed ${C.border}`,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,textAlign:"center",marginBottom:24}}><div style={{width:64,height:64,borderRadius:"50%",background:C.tealLight,display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,marginBottom:14}}>📷</div><p style={{color:C.inkMid,fontSize:13,fontWeight:600,marginBottom:6}}>SUMSUB VERIFICATION SDK</p><p style={{color:C.inkLight,fontSize:12,lineHeight:1.6,marginBottom:16}}>Document upload and liveness check handled by Sumsub within the SIKA wrapper.</p><div style={{display:"flex",gap:6,flexWrap:"wrap",justifyContent:"center"}}>{["Document scan","Selfie check","AML screening"].map(s=><span key={s} style={{background:C.tealLight,color:C.tealDark,fontSize:11,fontWeight:700,padding:"4px 10px",borderRadius:20}}>{s}</span>)}</div></div>
        <TealBtn onClick={()=>setOnbStep(5)}>Simulate: verification complete →</TealBtn>
      </div>
    );
    if(onbStep===5) return(
      <div style={{padding:"50px 24px 40px",display:"flex",flexDirection:"column",alignItems:"center",textAlign:"center",height:"100%"}}>
        <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
          <div style={{position:"relative",width:100,height:100,marginBottom:24}}><div style={{position:"absolute",inset:0,borderRadius:"50%",background:`conic-gradient(${C.lime} 0%,${C.teal} 60%,${C.lime} 100%)`,opacity:0.2}}/><div style={{position:"absolute",inset:8,borderRadius:"50%",background:C.bgCard,display:"flex",alignItems:"center",justifyContent:"center",fontSize:40}}>✓</div></div>
          <h2 style={{fontSize:24,fontWeight:800,color:C.ink,letterSpacing:"-0.8px",marginBottom:8,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>You're verified! 🎉</h2>
          <p style={{color:C.inkMid,fontSize:14,lineHeight:1.6,marginBottom:28,maxWidth:260}}>Your identity has been confirmed. Ready to send your first transfer.</p>
          <div style={{...card({width:"100%",textAlign:"left"}),background:C.limeLight,border:"1px solid #c8f07a"}}><div style={{display:"flex",gap:12,alignItems:"center"}}><div style={{width:36,height:36,borderRadius:10,background:C.lime,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>🎁</div><div><p style={{fontWeight:700,fontSize:14,color:C.ink}}>First transfer bonus</p><p style={{color:"#3d7a00",fontSize:12,marginTop:2}}>Zero fees — forever.</p></div></div></div>
        </div>
        <LimeBtn onClick={goHome} style={{marginBottom:10}}>Make my first transfer →</LimeBtn>
        <button onClick={goHome} style={{background:"transparent",border:"none",color:C.inkLight,fontSize:14,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>Explore the app first</button>
      </div>
    );
    return null;
  };

  // ══════════════════════════════════════════════════════
  // HOME
  // ══════════════════════════════════════════════════════
  const HomeScreen = () => {
    const art = ART[artIdx];
    return (
      <div style={{paddingBottom:8}}>
        <div style={{position:"relative",height:370,overflow:"hidden",cursor:"pointer"}} onClick={()=>setArtIdx((artIdx+1)%ART.length)}>
          <div style={{position:"absolute",inset:0,background:art.bg}}/>
          <div style={{position:"absolute",inset:0,background:art.overlay}}/>
          <ArtSilhouette i={artIdx}/>
          <div style={{position:"absolute",bottom:0,left:0,right:0,height:120,background:"linear-gradient(to bottom,transparent,rgba(0,0,0,0.55))"}}/>
          <div style={{position:"absolute",top:16,left:20}}><LogoFull white/></div>
          <div style={{position:"absolute",top:16,right:20,width:34,height:34,borderRadius:"50%",background:`linear-gradient(135deg,${C.teal},${C.tealDark})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:800,color:"#fff",border:"2px solid rgba(255,255,255,0.3)"}}>Y</div>
          <div style={{position:"absolute",bottom:18,left:20,right:80}}><p style={{color:"rgba(255,255,255,0.55)",fontSize:10,fontWeight:600,letterSpacing:"0.8px",textTransform:"uppercase",marginBottom:3}}>Dope Black Art · <span style={{color:C.lime}}>Featured Artist</span></p><p style={{color:"#fff",fontSize:15,fontWeight:700,fontFamily:"'Plus Jakarta Sans',sans-serif",lineHeight:1.2,textShadow:"0 1px 6px rgba(0,0,0,0.5)"}}>{art.title}</p><p style={{color:"rgba(255,255,255,0.55)",fontSize:12,marginTop:2}}>{art.artist}</p></div>
          <div style={{position:"absolute",bottom:22,right:20,display:"flex",gap:5}}>{ART.map((_,i)=><div key={i} onClick={e=>{e.stopPropagation();setArtIdx(i)}} style={{width:i===artIdx?18:6,height:6,borderRadius:3,background:i===artIdx?C.lime:"rgba(255,255,255,0.35)",transition:"width 0.3s",cursor:"pointer"}}/>)}</div>
        </div>

        <div style={{margin:"-28px 16px 0",position:"relative",zIndex:2}}>
          <div style={{background:"#fff",borderRadius:22,padding:"18px",boxShadow:"0 8px 32px rgba(0,0,0,0.12)",border:`1px solid ${C.border}`}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
              <div><p style={lbl({marginBottom:6})}>Live rate</p><div style={{display:"flex",alignItems:"center",gap:7}}><UKFlag/><span style={{color:C.inkMid,fontSize:12,fontWeight:600}}>GBP</span><span style={{color:C.inkLight,fontSize:14}}>→</span><GhanaFlag/><span style={{color:C.inkMid,fontSize:12,fontWeight:600}}>GHS</span></div></div>
              <div style={{textAlign:"right"}}><div style={{fontSize:28,fontWeight:800,color:C.teal,letterSpacing:"-1px",lineHeight:1,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{fxRate}</div><div style={{color:C.inkLight,fontSize:11,marginTop:2}}>per £1.00</div></div>
            </div>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:13}}>
              <div style={{display:"flex",alignItems:"center",gap:6}}><div style={{width:6,height:6,borderRadius:"50%",background:C.lime,boxShadow:`0 0 6px ${C.lime}`}}/><span style={{color:C.tealDark,fontSize:12,fontWeight:700}}>0% fees · Mid-market rate</span></div>
              <button onClick={()=>setScreen("alert")} style={{background:alertActive?C.lime:C.tealLight,color:alertActive?C.ink:C.tealDark,border:"none",borderRadius:8,padding:"4px 10px",fontSize:11,fontWeight:700,cursor:"pointer"}}>{alertActive?"🔔 On":"Set alert"}</button>
            </div>
            <TealBtn onClick={goSend}>Send money →</TealBtn>
          </div>
        </div>

        <div style={{padding:"18px 20px 0"}}>
          {/* Community pool teaser on home */}
          <div onClick={()=>setScreen("community")} style={{borderRadius:18,background:`linear-gradient(135deg,${C.community}15,${C.community}08)`,border:`1px solid ${C.community}30`,padding:"14px 16px",marginBottom:18,cursor:"pointer",display:"flex",alignItems:"center",gap:12}}>
            <div style={{width:38,height:38,borderRadius:11,background:C.community,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>🌱</div>
            <div style={{flex:1}}>
              <p style={{fontWeight:700,fontSize:13,color:C.community,marginBottom:2}}>Ghana Community Fund</p>
              <ProgressBar value={poolTotal} max={POOL_TARGET} color={C.community}/>
              <p style={{color:C.inkLight,fontSize:11,marginTop:4}}>GHS {poolTotal.toLocaleString()} raised of GHS {POOL_TARGET.toLocaleString()} goal</p>
            </div>
            <Arrow color={C.community}/>
          </div>

          <div style={{display:"flex",gap:10,marginBottom:22}}>
            {[{label:"Send",emoji:"↑",bg:C.tealLight,color:C.tealDark,action:goSend},{label:"History",emoji:"🕐",bg:C.limeLight,color:"#3d7a00",action:()=>setScreen("transfers")},{label:"Invite",emoji:"🎁",bg:"#FFF3E8",color:"#D4660A",action:()=>setScreen("refer")}].map(t=>(
              <div key={t.label} onClick={t.action} style={{flex:1,background:t.bg,borderRadius:16,padding:"14px 0",display:"flex",flexDirection:"column",alignItems:"center",gap:5,cursor:"pointer"}}>
                <span style={{fontSize:18,color:t.color}}>{t.emoji}</span><span style={{fontSize:11,fontWeight:700,color:t.color}}>{t.label}</span>
              </div>
            ))}
          </div>

          <p style={lbl({marginBottom:12})}>Recent Transfers</p>
          {[{name:"Yvonne Nana Idun",ghs:"5,248.87",gbp:"400.00",date:"31 Aug"},{name:"Emmanuel Keteku",ghs:"700.00",gbp:"55.89",date:"19 Aug"}].map(t=>(
            <div key={t.name} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"13px 0",borderBottom:`1px solid ${C.border}`}}>
              <div style={{display:"flex",alignItems:"center",gap:11}}><div style={{width:40,height:40,borderRadius:13,background:C.tealLight,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><GhanaFlag/></div><div><p style={{color:C.ink,fontSize:14,fontWeight:600,marginBottom:3}}>{t.name}</p><div style={{display:"flex",alignItems:"center",gap:5}}><Tick/><span style={{color:C.inkLight,fontSize:11}}>{t.date}</span></div></div></div>
              <div style={{textAlign:"right"}}><p style={{color:C.teal,fontSize:13,fontWeight:700}}>GHS {t.ghs}</p><p style={{color:C.inkLight,fontSize:12}}>£{t.gbp}</p></div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // ══════════════════════════════════════════════════════
  // SEND FLOW
  // ══════════════════════════════════════════════════════
  const SendScreen = () => (
    <div style={{padding:"0 20px",position:"relative"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,padding:"16px 0 18px"}}>
        <button onClick={sendStep===1?goHome:()=>setSendStep(s=>s-1)} style={{width:34,height:34,borderRadius:11,background:C.border,border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><Arrow dir="left" color={C.ink}/></button>
        <h2 style={{fontSize:20,fontWeight:800,color:C.ink,letterSpacing:"-0.5px",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{["","Send money","Who are you sending to?","Confirm transfer",""][sendStep]}</h2>
      </div>

      {/* Step 1 — Amount */}
      {sendStep===1 && <>
        <div style={{display:"flex",gap:6,marginBottom:20}}>{[1,2,3].map(s=><div key={s} style={{flex:1,height:4,borderRadius:10,background:s<=sendStep?C.teal:C.border}}/>)}</div>
        <div style={card({marginBottom:10})}><p style={lbl()}>You send</p><div style={{display:"flex",alignItems:"center",gap:10,marginTop:10}}><input value={amount} onChange={e=>setAmount(e.target.value.replace(/[^0-9.]/g,""))} style={{...bigN(),background:"transparent",border:"none",outline:"none",width:"100%",fontFamily:"'Plus Jakarta Sans',sans-serif"}} inputMode="decimal"/><div style={{display:"flex",alignItems:"center",gap:7,background:C.bg,border:`1px solid ${C.border}`,padding:"8px 12px",borderRadius:12,flexShrink:0}}><UKFlag/><span style={{fontWeight:700,fontSize:14,color:C.ink}}>GBP</span></div></div></div>
        <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:10,padding:"11px 16px",background:C.limeLight,border:"1px solid #c8f07a",borderRadius:12,marginBottom:10}}><span style={{fontSize:13,fontWeight:700,color:"#3d7a00"}}>1.00 GBP = {fxRate} GHS</span><Pill bg={C.lime} color={C.ink}>0% FEES</Pill></div>
        <div style={card({marginBottom:16,background:C.tealLight,border:"1px solid #b2ece8"})}><p style={lbl({color:C.tealDark})}>They receive</p><div style={{display:"flex",alignItems:"center",gap:10,marginTop:10}}><span style={bigN(C.teal)}>{receives}</span><div style={{display:"flex",alignItems:"center",gap:7,background:"#fff",border:`1px solid ${C.border}`,padding:"8px 12px",borderRadius:12,flexShrink:0,marginLeft:"auto"}}><GhanaFlag/><span style={{fontWeight:700,fontSize:14,color:C.ink}}>GHS</span></div></div></div>

        {/* Receive method */}
        <p style={lbl({marginBottom:10})}>Receive method</p>
        <div style={{marginBottom:16}}>
          {[
            {id:"mtn",      label:"MTN Mobile Money",    speed:"Instant",  color:"#FFCC00", textColor:"#7A5F00"},
            {id:"telecel",  label:"Telecel Cash",         speed:"Instant",  color:"#E30613", textColor:"#fff"},
            {id:"airteltigo",label:"AirtelTigo Money",   speed:"Instant",  color:"#FF6B00", textColor:"#fff"},
          ].map(n=>{
            const selected = (rxNetwork||"mtn")===n.id;
            return (
              <div key={n.id} onClick={()=>setRxNetwork(n.id)}
                style={{display:"flex",alignItems:"center",gap:12,padding:"13px 14px",background:selected?C.tealLight:C.bgCard,border:`1.5px solid ${selected?C.teal:C.border}`,borderRadius:14,marginBottom:8,cursor:"pointer",transition:"all 0.15s"}}>
                <div style={{width:36,height:36,borderRadius:10,background:n.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,fontWeight:900,color:n.textColor,flexShrink:0,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>M</div>
                <div style={{flex:1}}>
                  <p style={{fontWeight:700,fontSize:14,color:C.ink}}>{n.label}</p>
                  <p style={{color:C.inkLight,fontSize:12,marginTop:1}}>{n.speed} · £0.00</p>
                </div>
                <div style={{width:20,height:20,borderRadius:"50%",border:`2px solid ${selected?C.teal:C.border}`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                  {selected && <div style={{width:10,height:10,borderRadius:"50%",background:C.teal}}/>}
                </div>
              </div>
            );
          })}
        </div>

        {/* Community toggle in send flow */}
        <div style={{borderRadius:16,background:communityOn?`${C.community}12`:C.bg,border:`1.5px solid ${communityOn?C.community:C.border}`,padding:"14px 16px",marginBottom:16,transition:"all 0.2s"}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:communityOn?8:0}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:18}}>🌱</span>
              <div><p style={{fontWeight:700,fontSize:13,color:communityOn?C.community:C.ink}}>Help your community</p><p style={{color:C.inkLight,fontSize:11,marginTop:1}}>Add 0.1% to the Ghana Fund</p></div>
            </div>
            <Toggle on={communityOn} onToggle={()=>setCommunityOn(v=>!v)} color={C.community}/>
          </div>
          {communityOn && <div style={{background:`${C.community}15`,borderRadius:10,padding:"8px 12px",marginTop:4}}><p style={{fontSize:12,color:C.community,fontWeight:600}}>+£{communityContrib} added to the Ghana Community Fund 🇬🇭</p></div>}
        </div>

        <div style={{borderTop:`1px solid ${C.border}`,paddingTop:14,marginBottom:20}}>
          {[["Transfer fees","£0.00 FREE","#00C853"],["Exchange rate",`${fxRate} GHS/£`,C.inkMid],["Community",communityOn?`+£${communityContrib}`:"Off",communityOn?C.community:C.inkLight],["Total",`£${(parseFloat(amount||0)+(communityOn?parseFloat(communityContrib):0)).toFixed(2)}`,C.teal]].map(([k,v,col])=>(
            <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"6px 0"}}><span style={{color:C.inkLight,fontSize:13}}>{k}</span><span style={{color:col,fontSize:13,fontWeight:700}}>{v}</span></div>
          ))}
        </div>
        <TealBtn onClick={()=>setSendStep(2)}>Continue →</TealBtn>
      </>}

      {/* Step 2 — Receiver selection */}
      {sendStep===2 && (
        <div style={{position:"relative"}}>
          <div onClick={openAddReceiver} style={{display:"flex",alignItems:"center",gap:14,padding:"16px",background:C.tealLight,borderRadius:16,marginBottom:24,cursor:"pointer",border:`1px solid #b2ece8`}}>
            <div style={{width:48,height:48,borderRadius:14,background:C.teal,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"><circle cx="9" cy="7" r="4"/><path d="M3 21v-2a4 4 0 014-4h4a4 4 0 014 4v2"/><path d="M19 8v6M22 11h-6"/></svg></div>
            <span style={{fontWeight:700,fontSize:15,color:C.teal}}>Add new receiver</span>
          </div>
          <p style={lbl({marginBottom:12})}>Saved receivers</p>
          {receivers.map(rx=>(
            <div key={rx.id} style={{display:"flex",alignItems:"center",gap:12,padding:"14px 0",borderBottom:`1px solid ${C.border}`}}>
              <div onClick={()=>{setSelectedRx(rx);setSendStep(3)}} style={{display:"flex",alignItems:"center",gap:12,flex:1,cursor:"pointer"}}>
                <div style={{width:46,height:46,borderRadius:13,background:C.bg,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><GhanaFlag/></div>
                <div><p style={{color:C.ink,fontSize:15,fontWeight:700}}>{rx.first} {rx.last}</p><p style={{color:C.inkLight,fontSize:12,marginTop:2}}>📱 {rx.network==="telecel"?"Telecel":rx.network==="airteltigo"?"AirtelTigo":"MTN"} · +233 {rx.phone}</p></div>
              </div>
              <button onClick={()=>setSheetRx(rx)} style={{background:"transparent",border:"none",cursor:"pointer",padding:"6px 8px",color:C.inkLight,fontSize:18,lineHeight:1}}>···</button>
            </div>
          ))}
          {sheetRx && (
            <Sheet title="What would you like to do?" onClose={()=>setSheetRx(null)}>
              <div onClick={()=>openEditReceiver(sheetRx)} style={{display:"flex",alignItems:"center",gap:14,padding:"14px 0",cursor:"pointer",borderBottom:`1px solid ${C.border}`}}>
                <div style={{width:36,height:36,borderRadius:10,background:C.tealLight,display:"flex",alignItems:"center",justifyContent:"center"}}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.teal} strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></div>
                <span style={{fontWeight:700,fontSize:15,color:C.teal}}>Edit receiver</span>
              </div>
              <div onClick={()=>deleteReceiver(sheetRx.id)} style={{display:"flex",alignItems:"center",gap:14,padding:"14px 0",cursor:"pointer"}}>
                <div style={{width:36,height:36,borderRadius:10,background:"#FFEBEB",display:"flex",alignItems:"center",justifyContent:"center"}}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.danger} strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg></div>
                <span style={{fontWeight:700,fontSize:15,color:C.danger}}>Delete</span>
              </div>
            </Sheet>
          )}
        </div>
      )}

      {/* Step 3 — Confirm */}
      {sendStep===3 && selectedRx && <>
        <div style={{display:"flex",gap:6,marginBottom:20}}>{[1,2,3].map(s=><div key={s} style={{flex:1,height:4,borderRadius:10,background:s<=3?C.teal:C.border}}/>)}</div>
        <div style={card({marginBottom:12,background:C.tealLight,border:"1px solid #b2ece8"})}>
          <p style={lbl({color:C.tealDark,marginBottom:10})}>Sending to</p>
          <div style={{display:"flex",alignItems:"center",gap:12}}><div style={{width:44,height:44,borderRadius:13,background:"#fff",border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><GhanaFlag/></div><div><p style={{fontWeight:800,fontSize:16,color:C.ink,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{selectedRx.first} {selectedRx.last}</p><p style={{color:C.inkMid,fontSize:13,marginTop:2}}>📱 {selectedRx?.network==="telecel"?"Telecel Cash":selectedRx?.network==="airteltigo"?"AirtelTigo Money":"MTN MoMo"} · +233 {selectedRx.phone}</p></div></div>
        </div>
        <div style={card({marginBottom:16})}>
          {[["You send",`£${amount}`],["They receive",`GHS ${receives}`],["Fees","£0.00 ✓"],["Rate",`${fxRate} GHS/£`],["Delivery","Instant ⚡"],["Purpose",selectedRx.reason||"—"],["Community",communityOn?`£${communityContrib} → Ghana Fund`:"Not contributing"]].map(([k,v])=>(
            <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:`1px solid ${C.border}`}}><span style={{color:C.inkLight,fontSize:13}}>{k}</span><span style={{color:k==="Community"&&communityOn?C.community:C.ink,fontSize:13,fontWeight:700,maxWidth:"55%",textAlign:"right"}}>{v}</span></div>
          ))}
        </div>
        <TealBtn onClick={()=>setSendStep(4)}>Confirm & Send</TealBtn>
      </>}

      {/* Step 4 — Success */}
      {sendStep===4 && (
        <div style={{textAlign:"center",padding:"16px 10px"}}>
          <div style={{width:80,height:80,borderRadius:"50%",background:C.lime,display:"flex",alignItems:"center",justifyContent:"center",fontSize:38,margin:"0 auto 16px",boxShadow:`0 0 40px ${C.lime}88`}}>✓</div>
          <h2 style={{fontSize:24,fontWeight:800,color:C.ink,letterSpacing:"-0.5px",marginBottom:6,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Money sent! 🎉</h2>
          <p style={{color:C.inkMid,fontSize:14,lineHeight:1.6,marginBottom:20}}>On its way to <strong>{selectedRx?.first}</strong>. Typically instant.</p>
          {communityOn && (
            <div style={{display:"flex",alignItems:"center",gap:10,padding:"12px 16px",background:C.communityLight,border:`1px solid ${C.community}30`,borderRadius:14,marginBottom:16,textAlign:"left"}}>
              <span style={{fontSize:20}}>🌱</span>
              <div><p style={{fontWeight:700,fontSize:13,color:C.community}}>Thank you for contributing!</p><p style={{color:C.inkLight,fontSize:12,marginTop:1}}>£{communityContrib} added to the Ghana Community Fund</p></div>
            </div>
          )}
          <div style={card({textAlign:"left",marginBottom:20})}>
            {[["You sent",`£${amount}`],["They receive",`GHS ${receives}`],["Fees","£0.00"],["Delivery","Instant ⚡"]].map(([k,v])=>(
              <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"9px 0",borderBottom:`1px solid ${C.border}`}}><span style={{color:C.inkLight,fontSize:13}}>{k}</span><span style={{color:C.ink,fontSize:13,fontWeight:700}}>{v}</span></div>
            ))}
          </div>
          <TealBtn onClick={goHome} style={{marginBottom:10}}>Done</TealBtn>
          <button onClick={()=>setScreen("refer")} style={{background:"transparent",border:"none",color:C.teal,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>🎁 Invite a friend & earn £5 →</button>
        </div>
      )}
    </div>
  );

  // ══════════════════════════════════════════════════════
  // ADD / EDIT RECEIVER
  // ══════════════════════════════════════════════════════
  const EditReceiverScreen = () => (
    <div style={{padding:"0 20px",position:"relative"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,padding:"16px 0 20px"}}><button onClick={()=>{setScreen("send");setSendStep(2)}} style={{width:34,height:34,borderRadius:11,background:C.border,border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><Arrow dir="left" color={C.ink}/></button><h2 style={{fontSize:20,fontWeight:800,color:C.ink,letterSpacing:"-0.5px",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{editRx?"Edit receiver":"Add new receiver"}</h2></div>
      {editRx&&<div style={{background:"#EAF4FF",border:"1px solid #BDD8F5",borderRadius:14,padding:"12px 14px",marginBottom:16}}><p style={{fontSize:13,color:"#1a5fa8",lineHeight:1.5}}>Additional recipient details are required for regulatory purposes.</p></div>}
      <div style={{marginBottom:12}}>
        <p style={lbl({marginBottom:6})}>Receiver's name</p>
        <p style={{fontSize:12,color:C.inkLight,marginBottom:8}}>Enter the full name to avoid transfer delays.</p>
        <div style={{display:"flex",gap:8}}>
          <div style={{flex:1,background:C.bgCard,border:`1.5px solid ${C.border}`,borderRadius:14,padding:"12px 14px"}}><p style={{fontSize:10,color:C.inkLight,fontWeight:600,marginBottom:3}}>First name</p><input value={rxFirst} onChange={e=>setRxFirst(e.target.value)} placeholder="Kwame" style={{width:"100%",fontSize:15,fontWeight:600,color:C.ink,background:"transparent",border:"none",outline:"none",fontFamily:"'DM Sans',sans-serif"}}/><p style={{fontSize:10,color:C.inkLight,textAlign:"right",marginTop:2}}>{rxFirst.length}/40</p></div>
          <div style={{flex:1,background:C.bgCard,border:`1.5px solid ${C.border}`,borderRadius:14,padding:"12px 14px"}}><p style={{fontSize:10,color:C.inkLight,fontWeight:600,marginBottom:3}}>Last name</p><input value={rxLast} onChange={e=>setRxLast(e.target.value)} placeholder="Mensah" style={{width:"100%",fontSize:15,fontWeight:600,color:C.ink,background:"transparent",border:"none",outline:"none",fontFamily:"'DM Sans',sans-serif"}}/><p style={{fontSize:10,color:C.inkLight,textAlign:"right",marginTop:2}}>{rxLast.length}/40</p></div>
        </div>
      </div>
      <div style={{marginBottom:12}}>
        <p style={lbl({marginBottom:8})}>Mobile money number</p>
        <div style={{display:"flex",gap:8,marginBottom:8}}>
          <div style={{background:C.bg,border:`1.5px solid ${C.border}`,borderRadius:14,padding:"14px",flexShrink:0,minWidth:72}}><p style={{fontSize:10,color:C.inkLight,fontWeight:600,marginBottom:2}}>Code</p><p style={{fontSize:15,fontWeight:700,color:C.inkMid}}>+233</p></div>
          <div style={{flex:1,background:C.bgCard,border:`1.5px solid ${C.border}`,borderRadius:14,padding:"14px"}}><p style={{fontSize:10,color:C.inkLight,fontWeight:600,marginBottom:2}}>Mobile number</p><input value={rxPhone} onChange={e=>setRxPhone(e.target.value.replace(/\D/g,""))} placeholder="XX XXX XXXX" style={{width:"100%",fontSize:15,fontWeight:700,color:C.ink,background:"transparent",border:"none",outline:"none",fontFamily:"'DM Sans',sans-serif"}}/></div>
        </div>
        <p style={lbl({marginBottom:8})}>Network</p>
        <div style={{display:"flex",gap:8}}>
          {[{id:"mtn",label:"MTN MoMo",color:"#FFCC00"},{id:"telecel",label:"Telecel Cash",color:"#E30613"},{id:"airteltigo",label:"AirtelTigo",color:"#FF6B00"}].map(n=>{
            const sel=(rxNetwork||"mtn")===n.id;
            return(
              <div key={n.id} onClick={()=>setRxNetwork(n.id)} style={{flex:1,padding:"10px 6px",borderRadius:12,border:`1.5px solid ${sel?C.teal:C.border}`,background:sel?C.tealLight:C.bgCard,cursor:"pointer",textAlign:"center",transition:"all 0.15s"}}>
                <div style={{width:20,height:20,borderRadius:"50%",background:n.color,margin:"0 auto 5px"}}/>
                <p style={{fontSize:10,fontWeight:700,color:sel?C.teal:C.inkMid,lineHeight:1.3}}>{n.label}</p>
              </div>
            );
          })}
        </div>
      </div>
      <div style={{marginBottom:20}}>
        <p style={lbl({marginBottom:8})}>Reason for sending</p>
        <div onClick={()=>setShowReasonSheet(true)} style={{background:C.bgCard,border:`1.5px solid ${rxReason?C.teal:C.border}`,borderRadius:14,padding:"14px 16px",display:"flex",justifyContent:"space-between",alignItems:"center",cursor:"pointer"}}><span style={{fontSize:15,fontWeight:rxReason?700:400,color:rxReason?C.ink:C.inkLight}}>{rxReason||"Select a reason"}</span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.inkLight} strokeWidth="2"><path d="M6 9l6 6 6-6"/></svg></div>
      </div>
      <TealBtn onClick={saveReceiver}>Save and continue →</TealBtn>
      {showReasonSheet&&(
        <Sheet title="Reason for Sending" onClose={()=>setShowReasonSheet(false)}>
          {REASONS.map(r=><div key={r} onClick={()=>{setRxReason(r);setShowReasonSheet(false)}} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px 0",borderBottom:`1px solid ${C.border}`,cursor:"pointer"}}><span style={{fontSize:15,fontWeight:rxReason===r?700:500,color:rxReason===r?C.teal:C.ink}}>{r}</span>{rxReason===r&&<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.teal} strokeWidth="2.5"><path d="M5 13l4 4L19 7"/></svg>}</div>)}
        </Sheet>
      )}
    </div>
  );

  // ══════════════════════════════════════════════════════
  // HELP YOUR COMMUNITY SCREEN
  // ══════════════════════════════════════════════════════
  const CommunityScreen = () => {
    const pct = Math.round((poolTotal/POOL_TARGET)*100);
    const contributions = [
      {name:"Yaw M.",    amount:"£0.12", date:"Today"},
      {name:"Abena K.",  amount:"£0.08", date:"Today"},
      {name:"Kofi A.",   amount:"£0.45", date:"Yesterday"},
      {name:"Ama S.",    amount:"£0.22", date:"Yesterday"},
      {name:"Kwame B.",  amount:"£0.33", date:"2 days ago"},
    ];
    return (
      <div style={{padding:"0 20px"}}>
        <div style={{display:"flex",alignItems:"center",gap:12,padding:"16px 0 20px"}}><button onClick={goHome} style={{width:34,height:34,borderRadius:11,background:C.border,border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><Arrow dir="left" color={C.ink}/></button><h2 style={{fontSize:20,fontWeight:800,color:C.ink,letterSpacing:"-0.5px",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Help Your Community</h2></div>

        {/* Hero banner */}
        <div style={{borderRadius:22,background:`linear-gradient(140deg,#3D1A8F 0%,${C.community} 60%,#9B6BFF 100%)`,padding:"22px",marginBottom:16,position:"relative",overflow:"hidden"}}>
          <div style={{position:"absolute",top:-30,right:-30,width:140,height:140,borderRadius:"50%",background:C.lime,opacity:0.1}}/>
          <div style={{position:"absolute",bottom:-20,left:20,width:100,height:100,borderRadius:"50%",background:"#fff",opacity:0.05}}/>
          <p style={{color:"rgba(255,255,255,0.7)",fontSize:11,fontWeight:700,letterSpacing:"0.8px",textTransform:"uppercase",marginBottom:8}}>🇬🇭 Ghana Community Fund</p>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:14}}>
            <div><p style={{fontSize:32,fontWeight:800,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",letterSpacing:"-1px",lineHeight:1}}>GHS {poolTotal.toLocaleString()}</p><p style={{color:"rgba(255,255,255,0.6)",fontSize:12,marginTop:4}}>raised of GHS {POOL_TARGET.toLocaleString()} goal</p></div>
            <div style={{textAlign:"right"}}><p style={{fontSize:28,fontWeight:800,color:C.lime,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{pct}%</p><p style={{color:"rgba(255,255,255,0.5)",fontSize:11}}>funded</p></div>
          </div>
          <div style={{height:8,borderRadius:4,background:"rgba(255,255,255,0.2)",overflow:"hidden",marginBottom:14}}><div style={{height:"100%",width:`${pct}%`,background:C.lime,borderRadius:4}}/></div>
          <p style={{color:"rgba(255,255,255,0.7)",fontSize:12,lineHeight:1.5}}>Every transfer you make can contribute a tiny amount — 0.1% — that adds up to real community impact.</p>
        </div>

        {/* Your toggle */}
        <div style={{...card({marginBottom:14}),background:communityOn?C.communityLight:C.bgCard,border:`1.5px solid ${communityOn?C.community:C.border}`,transition:"all 0.2s"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
            <div><p style={{fontWeight:800,fontSize:15,color:communityOn?C.community:C.ink}}>Contribute on my transfers</p><p style={{color:C.inkLight,fontSize:12,marginTop:2}}>0.1% of each transfer you send</p></div>
            <Toggle on={communityOn} onToggle={()=>{setCommunityOn(v=>!v); if(!communityOn) setPoolTotal(p=>p+Math.round(parseFloat(amount||0)*0.001*16.42));}} color={C.community}/>
          </div>
          {communityOn
            ? <div style={{background:`${C.community}15`,borderRadius:10,padding:"8px 12px"}}><p style={{fontSize:12,color:C.community,fontWeight:600}}>✓ Active — thank you for contributing! 🙏🏾</p></div>
            : <div style={{background:C.bg,borderRadius:10,padding:"8px 12px"}}><p style={{fontSize:12,color:C.inkLight}}>Toggle on to start contributing to your community.</p></div>
          }
        </div>

        {/* What the fund does */}
        <div style={card({marginBottom:14})}>
          <p style={lbl({marginBottom:14})}>What the fund supports</p>
          {[
            {emoji:"🏫",title:"Education",desc:"School supplies and scholarships in rural Ghana"},
            {emoji:"💧",title:"Clean water",desc:"Borehole projects in underserved communities"},
            {emoji:"🌾",title:"Agriculture",desc:"Seed funding for smallholder farmers"},
            {emoji:"🛣️",title:"Infrastructure",desc:"Roads, sidewalks and open markets in local communities"},
          ].map(p=>(
            <div key={p.title} style={{display:"flex",gap:12,marginBottom:14,alignItems:"flex-start"}}>
              <div style={{width:38,height:38,borderRadius:11,background:C.communityLight,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>{p.emoji}</div>
              <div><p style={{fontWeight:700,fontSize:14,color:C.ink}}>{p.title}</p><p style={{color:C.inkLight,fontSize:12,marginTop:2,lineHeight:1.4}}>{p.desc}</p></div>
            </div>
          ))}
        </div>

        {/* Recent contributions */}
        <div style={card({marginBottom:20})}>
          <p style={lbl({marginBottom:12})}>Recent contributions</p>
          {contributions.map((c,i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:i<contributions.length-1?`1px solid ${C.border}`:"none"}}>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <div style={{width:32,height:32,borderRadius:"50%",background:C.communityLight,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:800,color:C.community}}>{c.name[0]}</div>
                <div><p style={{fontSize:13,fontWeight:600,color:C.ink}}>{c.name}</p><p style={{fontSize:11,color:C.inkLight}}>{c.date}</p></div>
              </div>
              <p style={{fontSize:13,fontWeight:700,color:C.community}}>{c.amount}</p>
            </div>
          ))}
        </div>

        <LimeBtn onClick={goSend}>Send money & contribute →</LimeBtn>
      </div>
    );
  };

  // ══════════════════════════════════════════════════════
  // REFERRAL SCREEN
  // ══════════════════════════════════════════════════════
  const ReferScreen = () => (
    <div style={{padding:"0 20px"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,padding:"16px 0 20px"}}><button onClick={goHome} style={{width:34,height:34,borderRadius:11,background:C.border,border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><Arrow dir="left" color={C.ink}/></button><h2 style={{fontSize:20,fontWeight:800,color:C.ink,letterSpacing:"-0.5px",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Invite a friend</h2></div>

      {/* Hero */}
      <div style={{borderRadius:22,background:`linear-gradient(140deg,#004D45 0%,${C.teal} 60%,#AAFF45 100%)`,padding:"24px",marginBottom:16,textAlign:"center",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",top:-20,right:-20,width:120,height:120,borderRadius:"50%",background:"#fff",opacity:0.06}}/>
        <div style={{fontSize:44,marginBottom:12}}>🎁</div>
        <h3 style={{fontSize:22,fontWeight:800,color:"#fff",letterSpacing:"-0.5px",marginBottom:6,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Send home together.</h3>
        <p style={{color:"rgba(255,255,255,0.75)",fontSize:14,lineHeight:1.6,marginBottom:16}}>Invite a friend to SIKA and you both win — the diaspora grows stronger together.</p>
        <div style={{display:"inline-flex",alignItems:"center",gap:8,background:"rgba(255,255,255,0.15)",borderRadius:12,padding:"8px 16px"}}>
          <span style={{color:"rgba(255,255,255,0.7)",fontSize:12,fontWeight:600}}>You earn</span>
          <span style={{color:C.lime,fontSize:20,fontWeight:800,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>£5</span>
          <span style={{color:"rgba(255,255,255,0.4)"}}>·</span>
          <span style={{color:"rgba(255,255,255,0.7)",fontSize:12,fontWeight:600}}>They earn</span>
          <span style={{color:C.lime,fontSize:20,fontWeight:800,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>£5</span>
        </div>
      </div>

      {/* Your code */}
      <div style={card({marginBottom:14})}>
        <p style={lbl({marginBottom:10})}>Your unique invite code</p>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <div style={{flex:1,background:`linear-gradient(135deg,${C.tealLight},${C.limeLight})`,borderRadius:14,padding:"14px 18px",border:`1.5px dashed ${C.teal}`}}>
            <p style={{fontSize:24,fontWeight:800,color:C.teal,letterSpacing:"2px",fontFamily:"'Plus Jakarta Sans',sans-serif",textAlign:"center"}}>{referralCode}</p>
          </div>
          <button onClick={copyCode} style={{background:codeCopied?C.lime:C.teal,color:codeCopied?C.ink:"#fff",border:"none",borderRadius:14,padding:"14px 18px",fontSize:13,fontWeight:800,cursor:"pointer",fontFamily:"'Plus Jakarta Sans',sans-serif",flexShrink:0,transition:"all 0.2s"}}>
            {codeCopied?"Copied! ✓":"Copy"}
          </button>
        </div>
        <p style={{color:C.inkLight,fontSize:11,textAlign:"center",marginTop:10,lineHeight:1.5}}>Share this code with friends. When they make their first transfer, you both get £5 credited to your next send.</p>
      </div>

      {/* Share options */}
      <div style={card({marginBottom:14})}>
        <p style={lbl({marginBottom:12})}>Share via</p>
        <div style={{display:"flex",gap:10}}>
          {[{emoji:"💬",label:"WhatsApp",color:"#25D366"},{emoji:"✉️",label:"iMessage",color:C.teal},{emoji:"🔗",label:"Copy link",color:C.inkMid}].map(s=>(
            <div key={s.label} style={{flex:1,background:C.bg,borderRadius:14,padding:"14px 8px",display:"flex",flexDirection:"column",alignItems:"center",gap:6,cursor:"pointer",border:`1px solid ${C.border}`}}>
              <span style={{fontSize:22}}>{s.emoji}</span>
              <span style={{fontSize:11,fontWeight:700,color:s.color}}>{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* How it works */}
      <div style={card({marginBottom:20})}>
        <p style={lbl({marginBottom:14})}>How it works</p>
        {[{n:"1",text:"Share your code SIKA-YAW with a friend"},{n:"2",text:"They sign up and complete identity check"},{n:"3",text:"They make their first transfer (any amount)"},{n:"4",text:"You both get £5 on your next transfer"}].map(s=>(
          <div key={s.n} style={{display:"flex",alignItems:"flex-start",gap:12,marginBottom:12}}>
            <div style={{width:24,height:24,borderRadius:"50%",background:C.teal,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:"#fff",flexShrink:0,marginTop:1}}>{s.n}</div>
            <p style={{color:C.inkMid,fontSize:13,lineHeight:1.5}}>{s.text}</p>
          </div>
        ))}
      </div>

      {/* Stats */}
      <div style={{display:"flex",gap:10,marginBottom:20}}>
        {[{label:"Friends invited",value:"0"},{label:"Rewards earned",value:"£0"},{label:"Pending",value:"0"}].map(s=>(
          <div key={s.label} style={{flex:1,background:C.bg,borderRadius:14,padding:"14px 10px",textAlign:"center",border:`1px solid ${C.border}`}}>
            <p style={{fontSize:20,fontWeight:800,color:C.teal,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{s.value}</p>
            <p style={{fontSize:10,color:C.inkLight,fontWeight:600,marginTop:3}}>{s.label}</p>
          </div>
        ))}
      </div>

      <TealBtn onClick={copyCode}>{codeCopied?"✓ Code copied!":"Share your invite code"}</TealBtn>
    </div>
  );

  // ── ALERT ────────────────────────────────────────────
  const AlertScreen = () => (
    <div style={{padding:"0 20px"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,padding:"16px 0 22px"}}><button onClick={goHome} style={{width:34,height:34,borderRadius:11,background:C.border,border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><Arrow dir="left" color={C.ink}/></button><h2 style={{fontSize:20,fontWeight:800,color:C.ink,letterSpacing:"-0.5px",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Rate Alert</h2></div>
      <div style={{borderRadius:20,background:`linear-gradient(135deg,${C.teal},${C.tealDark})`,padding:"20px",marginBottom:16,position:"relative",overflow:"hidden"}}><div style={{position:"absolute",top:-20,right:-20,width:100,height:100,borderRadius:"50%",background:C.lime,opacity:0.12}}/><p style={{color:"rgba(255,255,255,0.65)",fontSize:11,fontWeight:700,letterSpacing:"0.8px",textTransform:"uppercase",marginBottom:6}}>Current live rate</p><div style={{display:"flex",alignItems:"flex-end",gap:8,marginBottom:10}}><span style={{fontSize:36,fontWeight:800,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif",letterSpacing:"-1.5px",lineHeight:1}}>{fxRate}</span><span style={{color:"rgba(255,255,255,0.6)",fontSize:14,marginBottom:4}}>GHS per £1</span></div><div style={{display:"flex",gap:6,alignItems:"center"}}><div style={{width:6,height:6,borderRadius:"50%",background:C.lime}}/><span style={{color:C.lime,fontSize:12,fontWeight:700}}>Live · updates every 60s</span></div></div>
      <div style={card({marginBottom:14})}><p style={lbl({marginBottom:4})}>Notify me when rate reaches</p><p style={{color:C.inkLight,fontSize:12,marginBottom:14,lineHeight:1.5}}>We'll push notify you the moment GBP→GHS hits your target.</p><div style={{background:C.bg,border:`1.5px solid ${alertActive?C.teal:C.border}`,borderRadius:14,padding:"12px 16px",display:"flex",alignItems:"center",gap:8,marginBottom:8}}><div style={{display:"flex",alignItems:"center",gap:6}}><UKFlag/><span style={{color:C.inkMid,fontSize:13,fontWeight:600}}>£1 =</span></div><input value={alertRate} onChange={e=>setAlertRate(e.target.value.replace(/[^0-9.]/g,""))} style={{flex:1,fontSize:24,fontWeight:800,color:C.teal,background:"transparent",border:"none",outline:"none",fontFamily:"'Plus Jakarta Sans',sans-serif",letterSpacing:"-0.5px"}} inputMode="decimal"/><span style={{color:C.inkMid,fontSize:13,fontWeight:600}}>GHS</span></div>{parseFloat(alertRate)>fxRate&&<div style={{display:"flex",alignItems:"center",gap:6,padding:"8px 12px",background:C.limeLight,borderRadius:10}}><span style={{fontSize:14}}>📈</span><span style={{fontSize:12,color:"#3d7a00",fontWeight:600}}>+{(parseFloat(alertRate)-fxRate).toFixed(2)} GHS above today's rate</span></div>}{parseFloat(alertRate)<=fxRate&&alertRate&&<div style={{display:"flex",alignItems:"center",gap:6,padding:"8px 12px",background:"#FFF3E8",borderRadius:10}}><span style={{fontSize:14}}>⚠️</span><span style={{fontSize:12,color:"#D4660A",fontWeight:600}}>Rate already at this level — send now!</span></div>}</div>
      {alertActive?(<><div style={{display:"flex",alignItems:"center",gap:8,padding:"14px 18px",background:C.limeLight,border:"1px solid #c8f07a",borderRadius:14,marginBottom:14}}><span style={{fontSize:20}}>🔔</span><div><p style={{fontWeight:700,fontSize:14,color:C.ink}}>Alert active at {alertRate} GHS</p><p style={{color:"#3d7a00",fontSize:12,marginTop:2}}>We'll notify you the moment it's reached</p></div></div><GhostBtn onClick={()=>setAlertActive(false)}>Remove alert</GhostBtn></>):(<TealBtn onClick={()=>setAlertActive(true)}>🔔 Set rate alert for {alertRate} GHS</TealBtn>)}
    </div>
  );

  // ── TRANSFERS ─────────────────────────────────────────
  const TransfersScreen = () => (
    <div style={{padding:"0 20px"}}>
      <h2 style={{fontSize:22,fontWeight:800,color:C.ink,padding:"20px 0 18px",letterSpacing:"-0.5px",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>My transfers</h2>
      {[{name:"One Philipo Ventures",ghs:"1,230.00",gbp:"87.16",date:"8 Sep 2025"},{name:"Kwesi K. Asante",ghs:"315.00",gbp:"22.58",date:"5 Sep 2025"},{name:"Yvonne Nana Afua Idun",ghs:"5,248.87",gbp:"400.00",date:"31 Aug 2025"},{name:"Emmanuel Keteku",ghs:"700.00",gbp:"55.89",date:"19 Aug 2025"},{name:"Emmanuel Keteku",ghs:"1,000.00",gbp:"83.07",date:"13 Jul 2025"}].map((t,i)=>(
        <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"15px 0",borderBottom:`1px solid ${C.border}`}}>
          <div style={{display:"flex",alignItems:"center",gap:12}}><div style={{width:42,height:42,borderRadius:14,background:C.tealLight,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><GhanaFlag/></div><div><p style={{color:C.ink,fontSize:14,fontWeight:600,marginBottom:3}}>{t.name}</p><div style={{display:"flex",alignItems:"center",gap:5}}><Tick/><span style={{color:C.success,fontSize:11,fontWeight:600}}>Delivered</span><span style={{color:C.inkLight,fontSize:11}}> · {t.date}</span></div></div></div>
          <div style={{textAlign:"right"}}><p style={{color:C.teal,fontSize:13,fontWeight:700}}>GHS {t.ghs}</p><p style={{color:C.inkLight,fontSize:12}}>£{t.gbp}</p></div>
        </div>
      ))}
    </div>
  );

  // ══════════════════════════════════════════════════════
  // PROFILE / SETTINGS SCREEN
  // ══════════════════════════════════════════════════════
  const ProfileScreen = () => {
    const [biometric,  setBiometric]  = useState(true);
    const [pushNotifs, setPushNotifs] = useState(true);
    const [emailNotifs,setEmailNotifs]= useState(true);
    const [rateNotifs, setRateNotifs] = useState(alertActive);
    const totalContrib = communityOn ? "£1.24" : "£0.00";

    const Section = ({title, children}) => (
      <div style={{marginBottom:16}}>
        <p style={lbl({marginBottom:10})}>{title}</p>
        <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:20,overflow:"hidden"}}>
          {children}
        </div>
      </div>
    );
    const Row = ({emoji, label, value, onPress, danger=false, toggle=null, last=false}) => (
      <div onClick={onPress} style={{display:"flex",alignItems:"center",gap:12,padding:"14px 16px",borderBottom:last?"none":`1px solid ${C.border}`,cursor:onPress||toggle?"pointer":"default"}}>
        <div style={{width:34,height:34,borderRadius:10,background:danger?"#FFEBEB":C.tealLight,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>{emoji}</div>
        <div style={{flex:1}}>
          <p style={{fontSize:14,fontWeight:600,color:danger?C.danger:C.ink}}>{label}</p>
          {value && <p style={{fontSize:12,color:C.inkLight,marginTop:1}}>{value}</p>}
        </div>
        {toggle !== null ? toggle : onPress ? <Arrow color={C.inkLight}/> : null}
      </div>
    );

    return (
      <div style={{padding:"0 20px"}}>
        {/* Profile hero */}
        <div style={{padding:"20px 0 18px"}}>
          <div style={{display:"flex",alignItems:"center",gap:14}}>
            <div style={{position:"relative"}}>
              <div style={{width:64,height:64,borderRadius:20,background:`linear-gradient(135deg,${C.teal},${C.tealDark})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,fontWeight:800,color:"#fff",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Y</div>
              <div style={{position:"absolute",bottom:-2,right:-2,width:20,height:20,borderRadius:"50%",background:C.lime,border:"2px solid #fff",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10}}>✓</div>
            </div>
            <div style={{flex:1}}>
              <h2 style={{fontSize:20,fontWeight:800,color:C.ink,letterSpacing:"-0.5px",fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Yaw Mfodwo</h2>
              <p style={{color:C.inkLight,fontSize:13,marginTop:2}}>yaw@email.com</p>
              <div style={{display:"inline-flex",alignItems:"center",gap:5,marginTop:5,background:C.limeLight,border:"1px solid #c8f07a",borderRadius:20,padding:"3px 10px"}}>
                <div style={{width:6,height:6,borderRadius:"50%",background:C.success}}/>
                <span style={{fontSize:11,fontWeight:700,color:"#3d7a00"}}>Identity verified</span>
              </div>
            </div>
            <button onClick={()=>{}} style={{background:C.bg,border:`1px solid ${C.border}`,borderRadius:11,padding:"8px 12px",fontSize:12,fontWeight:700,color:C.inkMid,cursor:"pointer"}}>Edit</button>
          </div>
        </div>

        {/* Stats strip */}
        <div style={{display:"flex",gap:8,marginBottom:18}}>
          {[{label:"Transfers",value:"12"},{label:"Saved",value:"GHS "+poolTotal.toLocaleString()},{label:"Invited",value:"0 friends"}].map(s=>(
            <div key={s.label} style={{flex:1,background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:14,padding:"12px 8px",textAlign:"center"}}>
              <p style={{fontSize:16,fontWeight:800,color:C.teal,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>{s.value}</p>
              <p style={{fontSize:10,color:C.inkLight,fontWeight:600,marginTop:2}}>{s.label}</p>
            </div>
          ))}
        </div>

        {/* Send & Build summary */}
        <div style={{borderRadius:18,background:`linear-gradient(135deg,${C.community}18,${C.community}08)`,border:`1px solid ${C.community}25`,padding:"14px 16px",marginBottom:16,cursor:"pointer"}} onClick={()=>setScreen("community")}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
            <p style={{fontWeight:700,fontSize:13,color:C.community}}>🌱 Your community impact</p>
            <Arrow color={C.community}/>
          </div>
          <p style={{fontSize:22,fontWeight:800,color:C.community,fontFamily:"'Plus Jakarta Sans',sans-serif",letterSpacing:"-0.5px"}}>{totalContrib} <span style={{fontSize:13,fontWeight:500,color:C.inkLight}}>contributed to Ghana Fund</span></p>
        </div>

        {/* Account */}
        <Section title="Account">
          <Row emoji="👤" label="Personal details"     value="Name, email, phone"         onPress={()=>{}} />
          <Row emoji="🏦" label="Linked bank account"  value="Barclays ···4521"            onPress={()=>{}} />
          <Row emoji="🔑" label="Change password"                                          onPress={()=>{}} />
          <Row emoji="👁" label="Biometric login"       toggle={<Toggle on={biometric} onToggle={()=>setBiometric(v=>!v)}/>} last/>
        </Section>

        {/* Notifications */}
        <Section title="Notifications">
          <Row emoji="🔔" label="Push notifications"   toggle={<Toggle on={pushNotifs}  onToggle={()=>setPushNotifs(v=>!v)}/>} />
          <Row emoji="✉️"  label="Email updates"        toggle={<Toggle on={emailNotifs} onToggle={()=>setEmailNotifs(v=>!v)}/>} />
          <Row emoji="📈" label="Rate alerts"           toggle={<Toggle on={rateNotifs}  onToggle={()=>{setRateNotifs(v=>!v);setAlertActive(v=>!v);}}/> } last/>
        </Section>

        {/* Refer */}
        <Section title="Invite friends">
          <Row emoji="🎁" label="Your invite code"      value={referralCode}               onPress={()=>setScreen("refer")} last/>
        </Section>

        {/* Support */}
        <Section title="Support">
          <Row emoji="❓" label="Help & FAQs"                                              onPress={()=>{}} />
          <Row emoji="💬" label="Contact support"       value="We reply within 2 hours"   onPress={()=>{}} />
          <Row emoji="🚩" label="Report an issue"                                          onPress={()=>{}} last/>
        </Section>

        {/* Legal */}
        <Section title="Legal & regulatory">
          <Row emoji="📄" label="Terms of service"                                         onPress={()=>{}} />
          <Row emoji="🔒" label="Privacy policy"                                           onPress={()=>{}} />
          <Row emoji="🏛️" label="FCA authorisation"     value="Regulated under BaaS partner licence" onPress={()=>{}} last/>
        </Section>

        {/* Sign out */}
        <Section title="Account actions">
          <Row emoji="🚪" label="Sign out"              danger onPress={()=>setScreen("splash")} />
          <Row emoji="🗑️" label="Delete account"        danger onPress={()=>{}} last/>
        </Section>

        <p style={{textAlign:"center",color:C.inkLight,fontSize:11,paddingBottom:8,lineHeight:1.6}}>SIKA v1.0.0 · Made with 🖤 for the diaspora<br/>FCA authorised · Your money is protected</p>
      </div>
    );
  };

  // ══════════════════════════════════════════════════════
  // SHELL
  // ══════════════════════════════════════════════════════
  const isOnboarding = screen==="splash"||screen==="onboarding";
  const isHome       = screen==="home";
  const hideNav      = isOnboarding||screen==="editReceiver";

  return (
    <div style={{fontFamily:"'DM Sans','Helvetica Neue',sans-serif",background:"#D8F5F2",minHeight:"100vh",display:"flex",justifyContent:"center",alignItems:"center",padding:20}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@600;700;800&family=DM+Sans:wght@400;500;600&display=swap');
        * { box-sizing:border-box; margin:0; padding:0; }
        ::-webkit-scrollbar { display:none; }
        input::placeholder { color:#CCCCCC; }
      `}</style>

      <div style={{width:375,height:780,background:C.bg,borderRadius:44,overflow:"hidden",position:"relative",display:"flex",flexDirection:"column",boxShadow:"0 32px 80px rgba(0,196,180,0.22), 0 2px 0 rgba(255,255,255,0.8) inset",border:"1px solid rgba(255,255,255,0.6)"}}>
        {!isOnboarding&&(
          <div style={{display:"flex",justifyContent:"space-between",padding:"14px 26px 0",fontSize:12,fontWeight:700,position:"absolute",top:0,left:0,right:0,zIndex:10,pointerEvents:"none"}}>
            <span style={{color:isHome?"rgba(255,255,255,0.7)":C.inkMid}}>9:41</span>
            <span style={{color:isHome?"rgba(255,255,255,0.7)":C.inkMid}}>●●●● 🔋</span>
          </div>
        )}

        <div style={{flex:1,overflowY:"auto",paddingBottom:hideNav?0:80,scrollbarWidth:"none"}}>
          {screen==="splash"       && <SplashScreen/>}
          {screen==="onboarding"   && <OnboardingScreen/>}
          {screen==="home"         && <HomeScreen/>}
          {screen==="send"         && <SendScreen/>}
          {screen==="editReceiver" && <EditReceiverScreen/>}
          {screen==="transfers"    && <TransfersScreen/>}
          {screen==="alert"        && <AlertScreen/>}
          {screen==="community"    && <CommunityScreen/>}
          {screen==="refer"        && <ReferScreen/>}
          {screen==="profile"      && <ProfileScreen/>}
        </div>

        {!hideNav&&(
          <div style={{position:"absolute",bottom:0,left:0,right:0,background:"rgba(247,250,250,0.95)",backdropFilter:"blur(20px)",borderTop:`1px solid ${C.border}`,display:"flex",padding:"10px 8px 22px"}}>
            {NAV.map(({id,label,Icon})=>{
              const a=screen===id||(id==="send"&&screen==="send");
              return(
                <div key={id} onClick={()=>id==="send"?goSend():setScreen(id)} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:4,cursor:"pointer",padding:"4px 0"}}>
                  {a?<div style={{background:id==="community"?C.communityLight:C.tealLight,borderRadius:12,padding:"5px 14px"}}><Icon a/></div>:<Icon a={false}/>}
                  <span style={{fontSize:10,color:a?(id==="community"?C.community:C.teal):C.inkLight,fontWeight:a?700:500}}>{label}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
